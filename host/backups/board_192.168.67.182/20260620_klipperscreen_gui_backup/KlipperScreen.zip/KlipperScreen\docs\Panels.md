# Panels

### Splash Screen
![Splash_screen](img/panels/splash_screen.png)
!!! tip
    The *'power on'* button will only appear if a power device exists in moonraker and that power device name
    should be added to `power_devices`  in the printer section of the klipperscreen configuration file

### Main Menu
![Main Menu](img/panels/main_panel.png)

### [Job Status](Panels/Job_status.md)
```py
panel: job_status
```
[![Job Status](img/panels/job_status.png)](Panels/Job_status.md)

### [Bed Level](Panels/Screws.md)
```py
panel: bed_level
```
[![Bed Level](img/panels/bed_level.png)](Panels/Screws.md)

### Bed Mesh
```py
panel: bed_mesh
```
![Bed Mesh](img/panels/bed_mesh.png)

### Console
```py
panel: console
```
![Console](img/panels/console.png)

### Extrude
```py
panel: extrude theme:material-dark
```
![Extrude](img/panels/extrude.png)

### Fan
```py
panel: fan
```
![Fan](img/panels/fan.png)

### Fine Tune
```py
panel: fine_tune
```
![Fine Tune Panel](img/panels/fine_tune.png)

### Gcode Macros
```py
panel: gcode_macros
```
![Gcode Macros Panel](img/panels/gcode_macros.png)

### Input Shapers
```py
panel: input_shaper
```
![Limits](img/panels/input_shaper.png)

### Limits
```py
panel: limits
```
![Limits](img/panels/limits.png)

### Menu
![Menu Panel](img/panels/menu.png)

### Move
```py
panel: move
```
![Move Panel](img/panels/move.png)

### Network
```py
panel: network
```
![Network Panel](img/panels/network.png)

### Power
```py
panel: power
```
![Power](img/panels/power.png)

### Gcodes / Print
```py
panel: gcodes
```
![Gcodes Panel](img/panels/gcodes.png)

### Retraction
```py
panel: retraction
```
![Limits](img/panels/retraction.png)

### Settings
```py
panel: settings
```
![Settings](img/panels/settings.png)

### Spoolman
```py
panel: spoolman
```
![Spoolman](img/panels/spoolman.png)

### [Temperature](Panels/Temperature.md)
```py
panel: temperature
```
[![Temperature](img/panels/temperature.png)](Panels/Temperature.md)

### Updater
```py
panel: updater
```
![Updater Panel](img/panels/updater.png)

### [Z Calibrate](Panels/Zcalibrate.md)
```py
panel: zcalibrate
```
[![Z Calibrate](img/panels/zcalibrate.png)](Panels/Zcalibrate.md)
